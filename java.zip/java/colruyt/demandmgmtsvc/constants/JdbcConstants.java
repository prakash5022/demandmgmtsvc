package colruyt.demandmgmtsvc.constants;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JdbcConstants {
    public static final String URL = "jdbc:oracle:thin:@//dbsrvoractib0:1521/oractib0";
    public static final String PSWD = "EDU1D001ONTW";
    public static final String USERNAME = "EDU1D001ONTW";
    public static Connection CON = null;

}
