package colruyt.demandmgmtsvc;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/")
public class DemandRequestApplication extends Application {

}
