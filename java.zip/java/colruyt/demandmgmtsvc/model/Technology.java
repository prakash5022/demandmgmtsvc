package colruyt.demandmgmtsvc.model;

public class Technology {
    private String techName;
    private String techDescp;

    public String getTechName() {
        return techName;
    }

    public void setTechName(String techName) {
        this.techName = techName;
    }


    public String getTechDescp() {
        return techDescp;
    }

    public void setTechDescp(String techDescp) {
        this.techDescp = techDescp;
    }

}
