package colruyt.demandmgmtsvc.model;

public class DemandLevel {

    private String demandLevel;

    public String getDemandLevel() {
        return demandLevel;
    }

    public void setDemandLevel(String demandLevel) {
        this.demandLevel = demandLevel;
    }

}
