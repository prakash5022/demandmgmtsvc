package colruyt.demandmgmtsvc.dao;

import colruyt.demandmgmtsvc.model.DemandRequestEntity;

import java.util.List;

public interface DemandInterface {
    public List<String> getDemandRequestRoles();
    public List<String> getDemandRequestTechnologies();
    public String createDemandRequest(DemandRequestEntity demandRequest);
    public DemandRequestEntity getDemandRequestById(String id);
    public List<DemandRequestEntity> getAllDemandRequests();

}
