package colruyt.demandmgmtsvc.dao;


import colruyt.demandmgmtsvc.exceptions.*;
import colruyt.demandmgmtsvc.model.DemandRequestEntity;
import colruyt.demandmgmtsvc.util.DbUtil;
import colruyt.demandmgmtsvc.util.DemandRequestMapper;

import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;


import static colruyt.demandmgmtsvc.util.DbUtil.*;

public class DemandImpl implements DemandInterface{
    public SimpleDateFormat sdf1=new SimpleDateFormat("dd-MM-yyyy");
    public static final String getRoleQuery="SELECT ROLE_NAME FROM DEMAND_REQUEST_ROLE";

    public static final String queryId="SELECT * FROM DEMAND_REQUEST WHERE REQ_ID=?";

    public static final String findAllQuery="SELECT * FROM DEMAND_REQUEST";

   // public static final String get="SELECT NAME FROM Db";
    public static final String getTechnologyQuery="SELECT TECH_NAME FROM DEMAND_REQUEST_TECHNOLOGY";

    public static final String insertRecordQuery="INSERT INTO DEMAND_REQUEST(REQ_ID,ROLE,TECHNOLOGY,REQUESTED_BY,PROJECT,OPERATING_UNIT,REF_COMM_NO,DEMAND_LEVEL,REQUESTING_TM,RESPONSIBLE_TM,REQUESTED_DATE,TARGET_DATE,COMMENTS,STATUS) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    public static String DEMAND_REQUEST_SEQUENCE="SELECT Demand_Request_Sequence.NEXTVAL FROM DUAL";
    public static String getStatusQuery="SELECT STATUS_NAME FROM STATUS";
    public static String getLevelsQuery="SELECT DEM_LEVEL FROM DEMAND_LEVEL";

    public static String getRequestedByQuery="SELECT REQ_BY FROM REQUESTED_BY";
    Connection connection = null;
    Statement statement = null;
    ResultSet resultSet = null;
    PreparedStatement preparedStatement=null;

    DemandRequestEntity demandRequest=null;
    DemandRequestMapper demandRequestMapper=null;

    public DemandRequestEntity getDemandRequestById(String userId)throws DemandRequestNotFoundForGivenIdException {
        try {
            connection = dataSource.getConnection();
            preparedStatement= connection.prepareStatement(queryId);

            preparedStatement.setString(1,userId);
            resultSet = preparedStatement.executeQuery();
            if(resultSet.next()) {
                demandRequestMapper=new DemandRequestMapper();
                demandRequest=demandRequestMapper.set(resultSet);
            }else {
                throw new DemandRequestNotFoundForGivenIdException("No created request found for the given id"+userId);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        finally {
            closeConnection(resultSet,preparedStatement,statement,connection);
        }
        return demandRequest;
    }
    public List<DemandRequestEntity> getAllDemandRequests()throws DemandRequestNotCreatedException {
        List<DemandRequestEntity> demandRequestList = new ArrayList<>();
        try {
            connection = dataSource.getConnection();
            statement = connection.createStatement();
            resultSet = statement.executeQuery(findAllQuery);
            demandRequestMapper=new DemandRequestMapper();
            while (resultSet.next()) {
                demandRequest=demandRequestMapper.set(resultSet);
                demandRequestList.add(demandRequest);
            }
            if(demandRequestList.size()==0){
                throw new DemandRequestNotCreatedException("There are not created demand requests");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        finally {
            closeConnection(resultSet,preparedStatement,statement,connection);
        }
        return demandRequestList;
    }
    public List<String> getDemandRequestRoles()throws RolesNotFoundException {
        List<String>roles=new ArrayList<>();
        try {
            connection = dataSource.getConnection();
            statement = connection.createStatement();
            resultSet = statement.executeQuery(getRoleQuery);
            while (resultSet.next()) {
                roles.add(resultSet.getString("ROLE_NAME"));
            }
            if(roles.size()==0){
                throw new RolesNotFoundException("Roles not found");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        finally {
            closeConnection(resultSet,preparedStatement,statement,connection);
        }
        return roles;
    }

        public List<String> getDemandRequestTechnologies()throws TechnologyNotFoundException {
            List<String>technologies=new ArrayList<>();
            try {
                connection = dataSource.getConnection();
                statement = connection.createStatement();
                resultSet = statement.executeQuery(getTechnologyQuery);
                while (resultSet.next()) {
                    technologies.add(resultSet.getString("TECH_NAME"));
                }
                if(technologies.size()==0){
                    throw new TechnologyNotFoundException("Technologies not found");
                }
            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }
            finally {
                closeConnection(resultSet,preparedStatement,statement,connection);
            }
            return technologies;
    }

    private int getSequence(){
        int sequence=0;
        try{
            connection = dataSource.getConnection();
            statement= connection.createStatement();
            resultSet=statement.executeQuery(DEMAND_REQUEST_SEQUENCE);
            if(resultSet.next()){
                sequence=resultSet.getInt(1);
            }
            else{
                throw new SQLException();
            }
        }
        catch(SQLException e){
            System.out.println(e.getMessage());
        }
        finally {
            closeConnection(resultSet,preparedStatement,statement,connection);
        }
        return sequence;
    }
    public String createDemandRequest(DemandRequestEntity demandRequest)throws DemandRequestNotCreatedException {
        String res="";
        try{
            connection = dataSource.getConnection();
            PreparedStatement ps=connection.prepareStatement(insertRecordQuery);
            demandRequest.setStatus("NEW");
            for(int i=1;i<=demandRequest.getNoOfResources();i++) {
                String id="D"+String.format("%05d",getSequence());
                ps.setString(1, id);
                ps.setString(2, demandRequest.getRole());
                ps.setString(3, demandRequest.getTechnology());
                ps.setString(4, demandRequest.getRequestedBy());
                ps.setString(5, demandRequest.getProject());
                ps.setString(6, demandRequest.getOperatingUnit());
                ps.setString(7, demandRequest.getRefCommNo());
                ps.setString(8, demandRequest.getDemandLevel());
                ps.setString(9, demandRequest.getRequestingTm());
                ps.setString(10, demandRequest.getResponsibleTm());
                ps.setDate(11, new java.sql.Date(sdf1.parse(sdf1.format(demandRequest.getRequestedDate())).getTime()));
                ps.setDate(12, new java.sql.Date(sdf1.parse(sdf1.format(demandRequest.getTargetDate())).getTime()));
                ps.setString(13, demandRequest.getComments());
                ps.setString(14, demandRequest.getStatus());
                int a = ps.executeUpdate();
                if (a < 0) {
                    throw new DemandRequestNotCreatedException("Request not created in database");
                }
                res=res+id+" ";
            }
        }
        catch (SQLException e){
            System.out.println(e.getMessage());
        } catch (ParseException e) {
            System.out.println(e.getMessage());
        } finally {
           closeConnection(resultSet, preparedStatement, statement, connection);
       }
        return res;
    }
//    public List<DemandRequestEntity>searchDemandRequests(DemandRequestEntity demandRequestEntity)throws SearchByFieldException,FutureDateException, FromDateIsGreaterException{
//        List<String>al=new ArrayList<>();
//        List<DemandRequestEntity> demandRequestList = new ArrayList<>();
//        try {
//            String query=createSearchQuery(demandRequestEntity,al);
//            int inc=0;
//            connection=dataSource.getConnection();
//            preparedStatement= connection.prepareStatement(query);
//            for(int i=0;i<al.size();i++){
//                String res=al.get(i);
//                switch(res){
//                    case "REQ_ID":
//                        String id=demandRequestEntity.getReqId();
//                        preparedStatement.setString(++inc,id);
//                        break;
//                    case "ROLE": preparedStatement.setString(++inc,demandRequestEntity.getRole());
//                        break;
//                    case "REQUESTED_BY": preparedStatement.setString(++inc,demandRequestEntity.getRequestedBy());
//                        break;
//                    case "DEMAND_LEVEL":preparedStatement.setString(++inc, demandRequestEntity.getDemandLevel());
//                        break;
//                    case "RESPONSIBLE_TM":preparedStatement.setString(++inc, demandRequestEntity.getResponsibleTm());
//                    break;
//                    case "REQUESTED_DATE":preparedStatement.setDate(++inc,new java.sql.Date(sdf1.parse(sdf1.format(demandRequestEntity.getRequestedDate())).getTime()));
//                    break;
//                    case "TARGET_DATE":preparedStatement.setDate(++inc,new java.sql.Date(sdf1.parse(sdf1.format(demandRequestEntity.getTargetDate())).getTime()));
//                    break;
//                }
//            }
//            resultSet=preparedStatement.executeQuery();
//            DemandRequestMapper demandRequestMapper=new DemandRequestMapper();
//            while(resultSet.next()){
//                demandRequestEntity=demandRequestMapper.set(resultSet);
//                demandRequestList.add(demandRequestEntity);
//            }
//        }
//        catch (SQLException e){
//            System.out.println(e.getMessage());
//        } catch (ParseException e) {
//            System.out.println(e.getMessage());
//        }
//        if(demandRequestList.size()==0){
//            throw new SearchByFieldException("no results displayed for the entered search criteria");
//        }
//        return demandRequestList;
//    }
public List<DemandRequestEntity>searchDemandRequests(DemandRequestEntity demandRequestEntity)throws SearchByFieldException,FromDateIsGreaterException,FutureDateException{
    List<String>al=new ArrayList<>();
    List<DemandRequestEntity> demandRequestList = new ArrayList<>();
    try {
        String query=createSearchQuery(demandRequestEntity,al);
        int inc=0;
        connection=dataSource.getConnection();
        preparedStatement= connection.prepareStatement(query);
        for(int i=0;i<al.size();i++){
            String res=al.get(i);
            switch(res){
                case "REQ_ID":
                    String id=demandRequestEntity.getReqId();
                    preparedStatement.setString(++inc,id);
                    break;
                case "ROLE": preparedStatement.setString(++inc,demandRequestEntity.getRole());
                    break;
                case "REQUESTED_BY": preparedStatement.setString(++inc,demandRequestEntity.getRequestedBy());
                    break;
                case "DEMAND_LEVEL":preparedStatement.setString(++inc, demandRequestEntity.getDemandLevel());
                    break;
                case "RESPONSIBLE_TM":preparedStatement.setString(++inc, demandRequestEntity.getResponsibleTm());
                    break;
                case "FROM_DATE":preparedStatement.setDate(++inc,new java.sql.Date(sdf1.parse(sdf1.format(demandRequestEntity.getFromDate())).getTime()));
                    preparedStatement.setDate(++inc,new java.sql.Date(sdf1.parse(sdf1.format(demandRequestEntity.getToDate())).getTime()));
                    break;
                case "STATUS":preparedStatement.setString(++inc,demandRequestEntity.getStatus());
                    break;
            }
        }
        resultSet=preparedStatement.executeQuery();
        DemandRequestMapper demandRequestMapper=new DemandRequestMapper();
        while(resultSet.next()){
            demandRequestEntity=demandRequestMapper.set(resultSet);
            demandRequestList.add(demandRequestEntity);
        }
    }
    catch (SQLException e){
        System.out.println(e.getMessage());
    } catch (ParseException e) {
        System.out.println(e.getMessage());
    }
    if(demandRequestList.size()==0){
        throw new SearchByFieldException("no results displayed for the entered search criteria");
    }
    return demandRequestList;
}

    public List<String> getDemandRequestStatus()throws StatusNotFoundException {
        List<String>status=new ArrayList<>();
        try {
            connection = dataSource.getConnection();
            statement = connection.createStatement();
            resultSet = statement.executeQuery(getStatusQuery);
            while (resultSet.next()) {
                status.add(resultSet.getString("STATUS_NAME"));
            }
            if(status.size()==0){
                throw new StatusNotFoundException("Status not found");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        finally {
            closeConnection(resultSet,preparedStatement,statement,connection);
        }
        return status;
    }

    public List<String> getDemandRequestLevels()throws LevelsNotFoundException {
        List<String>levels=new ArrayList<>();
        try {
            connection = dataSource.getConnection();
            statement = connection.createStatement();
            resultSet = statement.executeQuery(getLevelsQuery);
            while (resultSet.next()) {
                levels.add(resultSet.getString("DEM_LEVEL"));
            }
            if(levels.size()==0){
                throw new LevelsNotFoundException("levels not found");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        finally {
            closeConnection(resultSet,preparedStatement,statement,connection);
        }
        return levels;
    }

    public void updateDemandRequest(DemandRequestEntity demandRequestEntity,String reqId) {
        List<Integer>al=new ArrayList<>();
        try {
            Connection con = dataSource.getConnection();
            PreparedStatement stm = con.prepareStatement(DbUtil.createUpdateQuery(demandRequestEntity,al));

            int max=1;
            for(Integer value:al){
                System.out.println(value+" value inside for");
                if(max>al.size()+1)break;
                switch (value){
                    case 1:stm.setString(max++,demandRequestEntity.getTechnology());break;
                    case 2:stm.setString(max++,demandRequestEntity.getProject());break;
                    case 3:stm.setString(max++,demandRequestEntity.getDemandLevel());break;
                    case 4:stm.setString(max++,demandRequestEntity.getRequestingTm());break;
                    case 5:stm.setString(max++,  demandRequestEntity.getResponsibleTm());break;
                    case 6:stm.setDate(max++, new java.sql.Date(sdf1.parse(sdf1.format(demandRequestEntity.getTargetDate())).getTime()));break;
                    case 7:stm.setString(max++,demandRequestEntity.getComments());break;
                    case 8:stm.setString(max++,demandRequestEntity.getStatus());break;
                    case 9:stm.setInt(max++,demandRequestEntity.getRequestToOffer());break;
                    case 10:stm.setDate(max++,(demandRequestEntity.getOfferedDate()!=null)?new java.sql.Date(sdf1.parse(sdf1.format(demandRequestEntity.getOfferedDate())).getTime()):null);
                    case 11:stm.setDate(max++,(demandRequestEntity.getDateOfJoiningOfferLetter()!=null)?new java.sql.Date(sdf1.parse(sdf1.format(demandRequestEntity.getDateOfJoiningOfferLetter())).getTime()):null);break;
                    case 12:stm.setInt(max++,demandRequestEntity.getRequestTojoining());break;
                    case 13:stm.setDate(max++,(demandRequestEntity.getActualJoiningDate()!=null)?new java.sql.Date(sdf1.parse(sdf1.format(demandRequestEntity.getActualJoiningDate())).getTime()):null);break;
                    case 14:stm.setString(max++,demandRequestEntity.getOfferSlaMet());break;
                    case 15:stm.setString(max++,demandRequestEntity.getRemarks());break;
                    case 16:stm.setString(max++,demandRequestEntity.getResourceName());break;
                }
            }
            stm.setString(max,reqId);
            ResultSet res=stm.executeQuery();


        }catch (SQLException e){
            System.out.println("Inside DemandImpl in update" + e.getMessage());
        }catch (ParseException e){
            System.out.println("Inside DemandImpl "+e.getMessage());
        }
    }

    public List<String> getRequestedBy() {
        List<String>requestedBy=new ArrayList<>();
        try {
            connection = dataSource.getConnection();
            statement = connection.createStatement();
            resultSet = statement.executeQuery(getRequestedByQuery);
            while (resultSet.next()) {
                requestedBy.add(resultSet.getString("REQ_BY"));
            }
            if(requestedBy.size()==0){
                throw new RequestedByNotFoundException("RequestedBy not found");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        finally {
            closeConnection(resultSet,preparedStatement,statement,connection);
        }
        return requestedBy;
    }
}
