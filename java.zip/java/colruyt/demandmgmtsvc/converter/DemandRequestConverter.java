package colruyt.demandmgmtsvc.converter;
//
//import colruyt.demandmgmtsvc.dto.DemandRequestDto;
//import colruyt.demandmgmtsvc.model.DemandRequestEntity;
//
//
//public class DemandRequestConverter extends Converter<DemandRequestDto, DemandRequestEntity> {
//      static DemandRequestDto demandRequestDto=null;
//    static DemandRequestEntity demandRequestEntity=null;
//
//    public DemandRequestConverter() {
//        super(DemandRequestConverter::convertToEntity, DemandRequestConverter::convertToDto);
//    }
//
//    public static DemandRequestDto convertToDto(DemandRequestEntity dREntity) {
//        demandRequestDto=new DemandRequestDto();
//        demandRequestDto.setReqId(dREntity.getReqId());
//        demandRequestDto.setRole(dREntity.getRole());
//        demandRequestDto.setTechnology(dREntity.getTechnology());
//        demandRequestDto.setRequestedBy(dREntity.getRequestedBy());
//        demandRequestDto.setProject(dREntity.getProject());
//        demandRequestDto.setOperatingUnit(dREntity.getOperatingUnit());
//        demandRequestDto.setRefCommNo(dREntity.getRefCommNo());
//        demandRequestDto.setNoOfResources(dREntity.getNoOfResources());
//        demandRequestDto.setDemandLevel(dREntity.getDemandLevel());
//        demandRequestDto.setRequestingTm(dREntity.getRequestingTm());
//        demandRequestDto.setResponsibleTm(dREntity.getResponsibleTm());
//        demandRequestDto.setRequestedDate(dREntity.getRequestedDate());
//        demandRequestDto.setTargetDate(dREntity.getTargetDate());
//        demandRequestDto.setComments(dREntity.getComments());
//        demandRequestDto.setStatus(dREntity.getStatus());
//        demandRequestDto.setOfferedDate(dREntity.getOfferedDate());
//        demandRequestDto.setOfferSlaMet(dREntity.getOfferSlaMet());
//        demandRequestDto.setDateOfJoiningOfferLetter(dREntity.getDateOfJoiningOfferLetter());
//        demandRequestDto.setActualJoiningDate(dREntity.getActualJoiningDate());
//        demandRequestDto.setRequestToOffer(dREntity.getRequestToOffer());
//        demandRequestDto.setRequestTojoining(dREntity.getRequestTojoining());
//        demandRequestDto.setResourceName(dREntity.getResourceName());
//        demandRequestDto.setRemarks(dREntity.getRemarks());
//        return demandRequestDto;
//    }
//
//    public static DemandRequestEntity convertToEntity(DemandRequestDto dRDto) {
//        demandRequestEntity=new DemandRequestEntity();
//        demandRequestEntity.setReqId(dRDto.getReqId());
//        demandRequestEntity.setRole(dRDto.getRole());
//        demandRequestEntity.setTechnology(dRDto.getTechnology());
//        demandRequestEntity.setRequestedBy(dRDto.getRequestedBy());
//        demandRequestEntity.setProject(dRDto.getProject());
//        demandRequestEntity.setOperatingUnit(dRDto.getOperatingUnit());
//        demandRequestEntity.setRefCommNo(dRDto.getRefCommNo());
//        demandRequestEntity.setNoOfResources(dRDto.getNoOfResources());
//        demandRequestEntity.setDemandLevel(dRDto.getDemandLevel());
//        demandRequestEntity.setRequestingTm(dRDto.getRequestingTm());
//        demandRequestEntity.setResponsibleTm(dRDto.getResponsibleTm());
//        demandRequestEntity.setRequestedDate(dRDto.getRequestedDate());
//        demandRequestEntity.setTargetDate(dRDto.getTargetDate());
//        demandRequestEntity.setComments(dRDto.getComments());
//        demandRequestEntity.setStatus(dRDto.getStatus());
//        demandRequestEntity.setOfferedDate(dRDto.getOfferedDate());
//        demandRequestEntity.setOfferSlaMet(dRDto.getOfferSlaMet());
//        demandRequestEntity.setDateOfJoiningOfferLetter(dRDto.getDateOfJoiningOfferLetter());
//        demandRequestEntity.setActualJoiningDate(dRDto.getActualJoiningDate());
//        demandRequestEntity.setRequestToOffer(dRDto.getRequestToOffer());
//        demandRequestEntity.setRequestTojoining(dRDto.getRequestTojoining());
//        demandRequestEntity.setResourceName(dRDto.getResourceName());
//        demandRequestEntity.setRemarks(dRDto.getRemarks());
//        return demandRequestEntity;
//    }
//
//}
//
////package com.colruytgroup.demandmgmtsvc.converter;

import colruyt.demandmgmtsvc.dto.DemandRequestDto;
//import com.colruytgroup.demandmgmtsvc.dto.DemandRequestDto;
import colruyt.demandmgmtsvc.model.DemandRequestEntity;
//import com.colruytgroup.demandmgmtsvc.model.DemandRequestEntity;


public class DemandRequestConverter extends Converter<DemandRequestDto, DemandRequestEntity> {
    static DemandRequestDto demandRequestDto=null;
    static DemandRequestEntity demandRequestEntity=null;

    public DemandRequestConverter() {
        super(DemandRequestConverter::convertToEntity, DemandRequestConverter::convertToDto);
    }

    public static DemandRequestDto convertToDto(DemandRequestEntity dREntity) {
        demandRequestDto=new DemandRequestDto();
        demandRequestDto.setReqId(dREntity.getReqId());
        demandRequestDto.setRole(dREntity.getRole());
        demandRequestDto.setTechnology(dREntity.getTechnology());
        demandRequestDto.setRequestedBy(dREntity.getRequestedBy());
        demandRequestDto.setProject(dREntity.getProject());
        demandRequestDto.setOperatingUnit(dREntity.getOperatingUnit());
        demandRequestDto.setRefCommNo(dREntity.getRefCommNo());
        demandRequestDto.setNoOfResources(dREntity.getNoOfResources());
        demandRequestDto.setDemandLevel(dREntity.getDemandLevel());
        demandRequestDto.setRequestingTm(dREntity.getRequestingTm());
        demandRequestDto.setResponsibleTm(dREntity.getResponsibleTm());
        demandRequestDto.setRequestedDate(dREntity.getRequestedDate());
        demandRequestDto.setTargetDate(dREntity.getTargetDate());
        demandRequestDto.setComments(dREntity.getComments());
        demandRequestDto.setStatus(dREntity.getStatus());
        demandRequestDto.setOfferedDate(dREntity.getOfferedDate());
        demandRequestDto.setOfferSlaMet(dREntity.getOfferSlaMet());
        demandRequestDto.setDateOfJoiningOfferLetter(dREntity.getDateOfJoiningOfferLetter());
        demandRequestDto.setActualJoiningDate(dREntity.getActualJoiningDate());
        demandRequestDto.setRequestToOffer(dREntity.getRequestToOffer());
        demandRequestDto.setRequestTojoining(dREntity.getRequestTojoining());
        demandRequestDto.setResourceName(dREntity.getResourceName());
        demandRequestDto.setRemarks(dREntity.getRemarks());
        demandRequestDto.setFromDate(dREntity.getFromDate());
        demandRequestDto.setToDate(dREntity.getToDate());
        return demandRequestDto;
    }

    public static DemandRequestEntity convertToEntity(DemandRequestDto dRDto) {
        demandRequestEntity=new DemandRequestEntity();
        demandRequestEntity.setReqId(dRDto.getReqId());
        demandRequestEntity.setRole(dRDto.getRole());
        demandRequestEntity.setTechnology(dRDto.getTechnology());
        demandRequestEntity.setRequestedBy(dRDto.getRequestedBy());
        demandRequestEntity.setProject(dRDto.getProject());
        demandRequestEntity.setOperatingUnit(dRDto.getOperatingUnit());
        demandRequestEntity.setRefCommNo(dRDto.getRefCommNo());
        demandRequestEntity.setNoOfResources(dRDto.getNoOfResources());
        demandRequestEntity.setDemandLevel(dRDto.getDemandLevel());
        demandRequestEntity.setRequestingTm(dRDto.getRequestingTm());
        demandRequestEntity.setResponsibleTm(dRDto.getResponsibleTm());
        demandRequestEntity.setRequestedDate(dRDto.getRequestedDate());
        demandRequestEntity.setTargetDate(dRDto.getTargetDate());
        demandRequestEntity.setComments(dRDto.getComments());
        demandRequestEntity.setStatus(dRDto.getStatus());
        demandRequestEntity.setOfferedDate(dRDto.getOfferedDate());
        demandRequestEntity.setOfferSlaMet(dRDto.getOfferSlaMet());
        demandRequestEntity.setDateOfJoiningOfferLetter(dRDto.getDateOfJoiningOfferLetter());
        demandRequestEntity.setActualJoiningDate(dRDto.getActualJoiningDate());
        demandRequestEntity.setRequestToOffer(dRDto.getRequestToOffer());
        demandRequestEntity.setRequestTojoining(dRDto.getRequestTojoining());
        demandRequestEntity.setResourceName(dRDto.getResourceName());
        demandRequestEntity.setRemarks(dRDto.getRemarks());
        demandRequestEntity.setFromDate(dRDto.getFromDate());
        demandRequestEntity.setToDate(dRDto.getToDate());
        return demandRequestEntity;
    }

}

