package colruyt.demandmgmtsvc.exceptions;

public class TechnologyNotFoundException extends RuntimeException {
    public TechnologyNotFoundException(String msg){
        super(msg);
    }
}
