package colruyt.demandmgmtsvc.exceptions;

public class RolesNotFoundException extends RuntimeException {
    public RolesNotFoundException(String msg){
        super(msg);
    }
}
