package colruyt.demandmgmtsvc.exceptions;

public class LevelsNotFoundException extends RuntimeException{
    public LevelsNotFoundException(String msg){
        super(msg);
    }
}
