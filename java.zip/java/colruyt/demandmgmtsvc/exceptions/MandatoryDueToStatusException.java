package colruyt.demandmgmtsvc.exceptions;

public class MandatoryDueToStatusException extends Exception{
    public MandatoryDueToStatusException(String msg){
        super(msg);
    }
}
