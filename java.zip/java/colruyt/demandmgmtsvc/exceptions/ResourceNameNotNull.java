package colruyt.demandmgmtsvc.exceptions;

public class ResourceNameNotNull extends Exception{
    public ResourceNameNotNull(String msg){
        super(msg);
    }
}
