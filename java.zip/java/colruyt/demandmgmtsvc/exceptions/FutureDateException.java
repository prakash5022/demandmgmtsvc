package colruyt.demandmgmtsvc.exceptions;

public class FutureDateException extends RuntimeException{
    public FutureDateException(String msg){
        super(msg);
    }
}
