package colruyt.demandmgmtsvc.exceptions;

public class FromDateIsGreaterException extends RuntimeException{
    public FromDateIsGreaterException(String msg){
        super(msg);
    }
}
