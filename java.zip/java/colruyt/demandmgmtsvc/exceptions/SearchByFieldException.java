package colruyt.demandmgmtsvc.exceptions;

public class SearchByFieldException extends RuntimeException {
    public SearchByFieldException(String msg){
        super(msg);
    }
}
