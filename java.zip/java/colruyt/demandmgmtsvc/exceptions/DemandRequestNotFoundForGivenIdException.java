package colruyt.demandmgmtsvc.exceptions;

public class DemandRequestNotFoundForGivenIdException extends RuntimeException {
    public DemandRequestNotFoundForGivenIdException(String msg){
        super(msg);
    }
}
