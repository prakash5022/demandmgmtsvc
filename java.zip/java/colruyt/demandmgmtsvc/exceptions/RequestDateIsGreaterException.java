package colruyt.demandmgmtsvc.exceptions;

public class RequestDateIsGreaterException extends RuntimeException{
    public  RequestDateIsGreaterException(String msg){
        super(msg);
    }
}
