package colruyt.demandmgmtsvc.exceptions;

public class DojGreaterThanOfferDateException extends Exception{
    public DojGreaterThanOfferDateException(String msg){
        super(msg);
    }
}
