package colruyt.demandmgmtsvc.exceptions;

public class NoDemandRequestCreatedException extends RuntimeException{
    public NoDemandRequestCreatedException(String msg){
        super(msg);
    }
}
