package colruyt.demandmgmtsvc.exceptions;

public class RequestedByNotFoundException extends RuntimeException{
    public RequestedByNotFoundException(String msg){
        super(msg);
    }
}
