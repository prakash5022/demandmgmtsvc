package colruyt.demandmgmtsvc.exceptions;

public class DemandRequestNotCreatedException extends RuntimeException {
    public DemandRequestNotCreatedException(String msg){
        super(msg);
    }
}
