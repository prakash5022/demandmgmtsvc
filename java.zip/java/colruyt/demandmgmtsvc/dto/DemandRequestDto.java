package colruyt.demandmgmtsvc.dto;
//
//import java.sql.Date;
//import java.util.Objects;
//import java.util.stream.Stream;
//
//public class DemandRequestDto {
//    private String reqId;
//    private String role;
//    private String technology;
//    private String requestedBy;
//    private String project;
//    private String operatingUnit;
//    private String refCommNo;
//    private Integer noOfResources;
//    private String demandLevel;
//    private String requestingTm;
//    private String responsibleTm;
//    private Date requestedDate;
//    private Date targetDate;
//    private String comments;
//    private String status;
//
//    private Date offeredDate;
//
//    private String offerSlaMet;
//
//    private Date dateOfJoiningOfferLetter;
//
//    private Date actualJoiningDate;
//
//    private Integer requestToOffer;
//
//    private Integer requestTojoining;
//
//    private String resourceName;
//
//    private String remarks;
//
//    private Date fromDate;
//
//
//    private Date toDate;
//
//    public Date getFromDate() {
//        return fromDate;
//    }
//
//    public void setFromDate(Date fromDate) {
//        this.fromDate = fromDate;
//    }
//    public Date getToDate() {
//        return toDate;
//    }
//
//    public void setToDate(Date toDate) {
//        this.toDate = toDate;
//    }
//
//
//
//    public void setReqId(String reqId){
//        this.reqId=reqId;
//    }
//
//    public String getReqId()
//    {
//        return reqId;
//    }
//
//    public String getRole() {
//
//
//
//        return role;
//    }
//
//    public void setRole(String role) {
//
//        this.role = role;
//    }
//
//
//
//    public String getTechnology() {
//
//        return technology;
//    }
//
//    public void setTechnology(String technology) {
//        this.technology = technology;
//    }
//
//
//
//    public String getRequestedBy() {
//
//        return requestedBy;
//    }
//
//    public void setRequestedBy(String requestedBy) {
//        this.requestedBy = requestedBy;
//    }
//
//
//
//    public String getProject() {
//
//        return project;
//    }
//
//    public void setProject(String project) {
//        this.project = project;
//    }
//
//
//
//    public String getOperatingUnit() {
//
//        return operatingUnit;
//    }
//
//    public void setOperatingUnit(String operatingUnit) {
//        this.operatingUnit = operatingUnit;
//    }
//
//
//
//    public String getRefCommNo() {
//
//        return refCommNo;
//    }
//
//    public void setRefCommNo(String refCommNo) {
//        this.refCommNo = refCommNo;
//    }
//
//
//
//    public Integer getNoOfResources(){
//
//        return noOfResources;
//    }
//
//    public void setNoOfResources(Integer noOfResources) {
//        this.noOfResources = noOfResources;
//    }
//
//
//
//    public String getDemandLevel() {
//
//        return demandLevel;
//    }
//
//    public void setDemandLevel(String demandLevel) {
//        this.demandLevel = demandLevel;
//    }
//
//
//
//    public String getRequestingTm() {
//
//        return requestingTm;
//    }
//
//    public void setRequestingTm(String requestingTm) {
//        this.requestingTm = requestingTm;
//    }
//
//
//
//    public String getResponsibleTm() {
//
//        return responsibleTm;
//    }
//
//    public void setResponsibleTm(String responsibleTm) {
//        this.responsibleTm = responsibleTm;
//    }
//
//
//
//    public Date getRequestedDate() {
//
//        return requestedDate;
//    }
//
//    public void setRequestedDate(Date requestedDate) {
//        this.requestedDate = requestedDate;
//    }
//
//
//
//    public Date getTargetDate() {
//
//        return targetDate;
//    }
//
//    public void setTargetDate(Date targetDate) {
//        this.targetDate = targetDate;
//    }
//
//
//
//    public String getComments() {
//        return comments;
//    }
//
//    public void setComments(String comments) {
//        this.comments = comments;
//    }
//
//
//
//    public String getStatus() {
//        return status;
//    }
//
//    public void setStatus(String status) {
//        this.status = status;
//    }
//
//    public Date getOfferedDate() {
//        return offeredDate;
//    }
//
//    public void setOfferedDate(Date offeredDate) {
//        this.offeredDate = offeredDate;
//    }
//
//    public String getOfferSlaMet() {
//        return offerSlaMet;
//    }
//
//    public void setOfferSlaMet(String offerSlaMet) {
//        this.offerSlaMet = offerSlaMet;
//    }
//
//    public Date getDateOfJoiningOfferLetter() {
//        return dateOfJoiningOfferLetter;
//    }
//
//    public void setDateOfJoiningOfferLetter(Date dateOfJoiningOfferLetter) {
//        this.dateOfJoiningOfferLetter = dateOfJoiningOfferLetter;
//    }
//
//    public Date getActualJoiningDate() {
//        return actualJoiningDate;
//    }
//
//    public void setActualJoiningDate(Date actualJoiningDate) {
//        this.actualJoiningDate = actualJoiningDate;
//    }
//
//    public Integer getRequestToOffer() {
//        return requestToOffer;
//    }
//
//    public void setRequestToOffer(Integer requestToOffer) {
//        this.requestToOffer = requestToOffer;
//    }
//
//    public Integer getRequestTojoining() {
//        return requestTojoining;
//    }
//
//    public void setRequestTojoining(Integer requestTojoining) {
//        this.requestTojoining = requestTojoining;
//    }
//
//    public String getResourceName() {
//        return resourceName;
//    }
//
//    public void setResourceName(String resourceName) {
//        this.resourceName = resourceName;
//    }
//
//    public String getRemarks() {
//        return remarks;
//    }
//
//    public void setRemarks(String remarks) {
//        this.remarks = remarks;
//    }
//
//    public boolean checkIfNullIsPresent(){
//        return Stream.of(role, technology, requestedBy, project, operatingUnit, refCommNo, noOfResources, demandLevel, requestingTm, responsibleTm, requestedDate,targetDate)
//                .anyMatch(Objects::isNull);
//    }
//    public boolean checkIfNotNullIsPresent(){
//        return Stream.of(reqId,role, technology, requestedBy, demandLevel,requestingTm,responsibleTm,fromDate)
//                .anyMatch(Objects::nonNull);
//    }
//}

//package com.colruytgroup.demandmgmtsvc.dto;

import java.sql.Date;
import java.util.Objects;
import java.util.stream.Stream;

public class DemandRequestDto {
    private String reqId;
    private String role;
    private String technology;
    private String requestedBy;
    private String project;
    private String operatingUnit;
    private String refCommNo;
    private Integer noOfResources;
    private String demandLevel;
    private String requestingTm;
    private String responsibleTm;
    private Date requestedDate;
    private Date targetDate;
    private String comments;
    private String status;

    private Date offeredDate;

    private String offerSlaMet;

    private Date dateOfJoiningOfferLetter;

    private Date actualJoiningDate;

    private Integer requestToOffer;

    private Integer requestTojoining;

    private String resourceName;
    private String remarks;
    private Date fromDate;
    private Date toDate;

    public Date getFromDate() {
        return fromDate;
    }

    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }

    public Date getToDate() {
        return toDate;
    }

    public void setToDate(Date toDate) {
        this.toDate = toDate;
    }



    public void setReqId(String reqId){
        this.reqId=reqId;
    }

    public String getReqId()
    {
        return reqId;
    }

    public String getRole() {



        return role;
    }

    public void setRole(String role) {

        this.role = role;
    }



    public String getTechnology() {

        return technology;
    }

    public void setTechnology(String technology) {
        this.technology = technology;
    }



    public String getRequestedBy() {

        return requestedBy;
    }

    public void setRequestedBy(String requestedBy) {
        this.requestedBy = requestedBy;
    }



    public String getProject() {

        return project;
    }

    public void setProject(String project) {
        this.project = project;
    }



    public String getOperatingUnit() {

        return operatingUnit;
    }

    public void setOperatingUnit(String operatingUnit) {
        this.operatingUnit = operatingUnit;
    }



    public String getRefCommNo() {

        return refCommNo;
    }

    public void setRefCommNo(String refCommNo) {
        this.refCommNo = refCommNo;
    }



    public Integer getNoOfResources(){

        return noOfResources;
    }

    public void setNoOfResources(Integer noOfResources) {
        this.noOfResources = noOfResources;
    }



    public String getDemandLevel() {

        return demandLevel;
    }

    public void setDemandLevel(String demandLevel) {
        this.demandLevel = demandLevel;
    }



    public String getRequestingTm() {

        return requestingTm;
    }

    public void setRequestingTm(String requestingTm) {
        this.requestingTm = requestingTm;
    }



    public String getResponsibleTm() {

        return responsibleTm;
    }

    public void setResponsibleTm(String responsibleTm) {
        this.responsibleTm = responsibleTm;
    }



    public Date getRequestedDate() {

        return requestedDate;
    }

    public void setRequestedDate(Date requestedDate) {
        this.requestedDate = requestedDate;
    }



    public Date getTargetDate() {

        return targetDate;
    }

    public void setTargetDate(Date targetDate) {
        this.targetDate = targetDate;
    }



    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }



    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getOfferedDate() {
        return offeredDate;
    }

    public void setOfferedDate(Date offeredDate) {
        this.offeredDate = offeredDate;
    }

    public String getOfferSlaMet() {
        return offerSlaMet;
    }

    public void setOfferSlaMet(String offerSlaMet) {
        this.offerSlaMet = offerSlaMet;
    }

    public Date getDateOfJoiningOfferLetter() {
        return dateOfJoiningOfferLetter;
    }

    public void setDateOfJoiningOfferLetter(Date dateOfJoiningOfferLetter) {
        this.dateOfJoiningOfferLetter = dateOfJoiningOfferLetter;
    }

    public Date getActualJoiningDate() {
        return actualJoiningDate;
    }

    public void setActualJoiningDate(Date actualJoiningDate) {
        this.actualJoiningDate = actualJoiningDate;
    }

    public Integer getRequestToOffer() {
        return requestToOffer;
    }

    public void setRequestToOffer(Integer requestToOffer) {
        this.requestToOffer = requestToOffer;
    }

    public Integer getRequestTojoining() {
        return requestTojoining;
    }

    public void setRequestTojoining(Integer requestTojoining) {
        this.requestTojoining = requestTojoining;
    }

    public String getResourceName() {
        return resourceName;
    }

    public void setResourceName(String resourceName) {
        this.resourceName = resourceName;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public boolean checkIfNullIsPresent(){
        return Stream.of(role, technology, requestedBy, project, operatingUnit, refCommNo, noOfResources, demandLevel, requestingTm, responsibleTm, requestedDate,targetDate)
                .anyMatch(Objects::isNull);
    }
    public boolean checkIfNotNullIsPresent(){
        return Stream.of(reqId,role, requestedBy,demandLevel, requestingTm, responsibleTm,fromDate,status)
                .anyMatch(Objects::nonNull);
    }
}
