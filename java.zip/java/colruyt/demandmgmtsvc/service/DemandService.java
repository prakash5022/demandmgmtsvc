package colruyt.demandmgmtsvc.service;

import colruyt.demandmgmtsvc.converter.DemandRequestConverter;
import colruyt.demandmgmtsvc.dao.DemandImpl;
import colruyt.demandmgmtsvc.exceptions.*;
import colruyt.demandmgmtsvc.dto.DemandRequestDto;
import colruyt.demandmgmtsvc.model.DemandRequestEntity;

import java.util.List;

public class DemandService {

    DemandImpl demandImpl=null;
    DemandRequestDto demandRequestDto=null;
    DemandRequestEntity demandRequestEntity=null;
    DemandRequestConverter userConverter=null;
    List<DemandRequestEntity>demandRequestEntities=null;
    List<DemandRequestDto>demandRequestDtos=null;
    public List<String> getDemandRequestRoles()throws RolesNotFoundException {
        demandImpl=new DemandImpl();
        return demandImpl.getDemandRequestRoles();
    }
    public List<String> getDemandRequestTechnologies()throws TechnologyNotFoundException {
        demandImpl=new DemandImpl();
        return demandImpl.getDemandRequestTechnologies();
    }
    public String createDemandRequest(DemandRequestDto demandRequestDto)throws DemandRequestNotCreatedException{
        demandImpl=new DemandImpl();
        userConverter=new DemandRequestConverter();
        demandRequestEntity=userConverter.convertFromDto(demandRequestDto);
        return demandImpl.createDemandRequest(demandRequestEntity);
    }
    public DemandRequestDto getDemandRequestById(String id)throws DemandRequestNotFoundForGivenIdException {
        demandImpl=new DemandImpl();
        demandRequestEntity=demandImpl.getDemandRequestById(id);
        userConverter=new DemandRequestConverter();
        demandRequestDto=userConverter.convertFromEntity(demandRequestEntity);
        return demandRequestDto;
    }
    public List<DemandRequestDto> getAllDemandRequests()throws DemandRequestNotCreatedException{
        demandImpl=new DemandImpl();
        userConverter=new DemandRequestConverter();
        demandRequestEntities=demandImpl.getAllDemandRequests();
        demandRequestDtos=userConverter.createFromEntities(demandRequestEntities);
        return demandRequestDtos;
    }
    public List<DemandRequestDto>searchDemandRequests(DemandRequestDto demandRequestDto)throws SearchByFieldException,FutureDateException, FromDateIsGreaterException{
        demandImpl=new DemandImpl();
        userConverter=new DemandRequestConverter();
        demandRequestEntity=userConverter.convertFromDto(demandRequestDto);
        demandRequestEntities=demandImpl.searchDemandRequests(demandRequestEntity);
        demandRequestDtos=userConverter.createFromEntities(demandRequestEntities);
        return demandRequestDtos;
    }

    public List<String> getDemandRequestStatus()throws StatusNotFoundException {
        demandImpl=new DemandImpl();
        return demandImpl.getDemandRequestStatus();
    }

    public List<String> getDemandRequestLevels()throws LevelsNotFoundException {
        demandImpl=new DemandImpl();
        return demandImpl.getDemandRequestLevels();
    }

    public void updateDemandRequest(DemandRequestDto demandRequestDto, String reqId) {
        demandImpl=new DemandImpl();
        userConverter=new DemandRequestConverter();
        demandRequestEntity=userConverter.convertFromDto(demandRequestDto);
        demandImpl.updateDemandRequest(demandRequestEntity,reqId);
    }

    public List<String> getRequestedBy() {
        demandImpl=new DemandImpl();
        return demandImpl.getRequestedBy();
    }
}
