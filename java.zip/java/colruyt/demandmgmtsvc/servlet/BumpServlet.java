package colruyt.demandmgmtsvc.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/bump")
public class BumpServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	private void bump(HttpServletRequest request, HttpServletResponse response) throws IOException {

		int code = 401;
		if (request.getParameter("code") != null) {
			code = Integer.parseInt(request.getParameter("code"));
		}
		response.reset();
		response.setHeader("Access-Control-Allow-Origin", request.getHeader("Origin"));
		response.setHeader("Access-Control-Allow-Credentials", "true");
		response.getWriter().println("No valid authentication/authorization");
		response.setStatus(code);
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		bump(request, response);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		bump(request, response);
	}

	@Override
	protected void doOptions(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		bump(request, response);
	}

}
