package colruyt.demandmgmtsvc.util;

import colruyt.demandmgmtsvc.exceptions.*;
import colruyt.demandmgmtsvc.model.DemandRequestEntity;
import org.apache.commons.dbcp2.BasicDataSource;

import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Date;


import static colruyt.demandmgmtsvc.constants.JdbcConstants.*;

public class DbUtil {
    public static SimpleDateFormat sdf1=new SimpleDateFormat("dd-MM-yyyy");
    public static BasicDataSource dataSource = null;

    static {
        dataSource = new BasicDataSource();
        dataSource.setUrl(URL);
        dataSource.setUsername(USERNAME);
        dataSource.setPassword(PSWD);

        dataSource.setMinIdle(5);
        dataSource.setMaxIdle(10);
        dataSource.setMaxTotal(25);

    }
    public static void closeConnection(ResultSet resultSet, PreparedStatement preparedStatement, Statement statement,Connection connection){
        if(resultSet!=null){
            try{
                resultSet.close();
            }
            catch (SQLException e){
                System.out.println(e.getMessage());
            }
            }
        if(preparedStatement!=null){
            try{
                preparedStatement.close();
            }
            catch(SQLException e){
                System.out.println(e.getMessage());
            }
        }
        if(statement!=null){
            try{
                statement.close();
            }
            catch(SQLException e){
                System.out.println(e.getMessage());
            }
        }
        if(connection!=null){
            try{
                connection.close();
            }
            catch (SQLException e){
                System.out.println(e.getMessage());
            }
        }
        }
        public static  String createSearchQuery(DemandRequestEntity demandRequestEntity, List<String>al) throws FutureDateException, FromDateIsGreaterException, ParseException{
            String s="";
            if (demandRequestEntity.getReqId() != null) {
                s="REQ_ID=?";
                al.add("REQ_ID");
            }
            if (demandRequestEntity.getRole() != null) {
                if(s.length()>0){
                    s=s+" and ROLE=?";
                }
                else{
                    s="ROLE=?";
                }
                al.add("ROLE");
            }
            if(demandRequestEntity.getRequestedBy()!=null){
                if(s.length()>0){
                    s=s+" and REQUESTED_BY=?";
                }
                else{
                    s="REQUESTED_BY=?";
                }
                al.add("REQUESTED_BY");
            }
            if(demandRequestEntity.getDemandLevel()!=null){
                if(s.length()>0){
                    s=s+" and DEMAND_LEVEL=?";
                }
                else{
                    s="DEMAND_LEVEL=?";
                }
                al.add("DEMAND_LEVEL");
            }
            if(demandRequestEntity.getResponsibleTm()!=null){
                if(s.length()>0){
                    s=s+" and RESPONSIBLE_TM=?";
                }
                else{
                    s="RESPONSIBLE_TM=?";
                }
                al.add("RESPONSIBLE_TM");
            }
            Date date=new Date();
            if(demandRequestEntity.getFromDate()!=null){
                 if(s.length()>0)s+=" and ";
                 if(demandRequestEntity.getFromDate().after(date))throw new FutureDateException("Future date is not possible");
                 if(demandRequestEntity.getToDate()!=null){
                 if(demandRequestEntity.getToDate().after(date))throw new FutureDateException("Future date is not possible");
                 }
                 else{
                 demandRequestEntity.setToDate(new java.sql.Date(sdf1.parse(sdf1.format(date)).getTime()));
                 }
                 if(demandRequestEntity.getFromDate().after(demandRequestEntity.getToDate()))throw new FromDateIsGreaterException("From date cannot be greater than to date.");
                  s+="requested_date between ? and ?";
                  al.add("FROM_DATE");
            }
            String query="select * from DEMAND_REQUEST where  "+s;
            return query;
        }
//public static  String createSearchQuery(DemandRequestEntity demandRequestEntity, List<String>al) throws FutureDateException, FromDateIsGreaterException, ParseException{
//    String s="";
//    if (demandRequestEntity.getReqId() != null) {
//        s="REQ_ID=?";
//        al.add("REQ_ID");
//    }
//    if (demandRequestEntity.getRole() != null) {
//        if(s.length()>0){
//            s=s+" and ROLE=?";
//        }
//        else{
//            s="ROLE=?";
//        }
//        al.add("ROLE");
//    }
//    if(demandRequestEntity.getRequestedBy()!=null){
//        if(s.length()>0){
//            s=s+" and REQUESTED_BY=?";
//        }
//        else{
//            s="REQUESTED_BY=?";
//        }
//        al.add("REQUESTED_BY");
//    }
//    if(demandRequestEntity.getDemandLevel()!=null){
//        if(s.length()>0){
//            s=s+" and DEMAND_LEVEL=?";
//        }
//        else{
//            s="DEMAND_LEVEL=?";
//        }
//        al.add("DEMAND_LEVEL");
//    }
//    if(demandRequestEntity.getResponsibleTm()!=null){
//        if(s.length()>0){
//            s=s+" and RESPONSIBLE_TM=?";
//        }
//        else{
//            s="RESPONSIBLE_TM=?";
//        }
//        al.add("RESPONSIBLE_TM");
//    }
//    Date date=new Date();
//    if(demandRequestEntity.getFromDate()!=null){
//        if(s.length()>0)s+=" and ";
//        if(demandRequestEntity.getFromDate().after(date))throw new FutureDateException("Future date is not possible");
//        if(demandRequestEntity.getToDate()!=null){
//            if(demandRequestEntity.getToDate().after(date))throw new FutureDateException("Future date is not possible");
//        }
//        else{
//            demandRequestEntity.setToDate(new java.sql.Date(sdf1.parse(sdf1.format(date)).getTime()));
//        }
//        if(demandRequestEntity.getFromDate().after(demandRequestEntity.getToDate()))throw new FromDateIsGreaterException("From date cannot be greater than to date.");
//        s+="requested_date between ? and ?";
//        al.add("FROM_DATE");
//    }
//    if(demandRequestEntity.getStatus()!=null){
//        if(s.length()>0){
//            s=s+" and STATUS=?";
//        }
//        else{
//            s="STATUS=?";
//        }
//        al.add("STATUS");
//    }
//    String query="select * from DEMAND_REQUEST where  "+s;
//    return query;
//}

        public static String createUpdateQuery(DemandRequestEntity demandRequestEntity,List<Integer>al){
            String query="";
            if(demandRequestEntity.getTechnology()!=null){
                query+=" Technology=?";
                al.add(1);
            }
            if(demandRequestEntity.getProject()!=null){
                if(query.length()>1)query+=" ,";
                query+=" project=?";
                al.add(2);
            }
            if(demandRequestEntity.getDemandLevel()!=null){
                if(query.length()>1)query+=" ,";
                query+=" demand_level=?";
                al.add(3);
            }
            if(demandRequestEntity.getRequestingTm()!=null){
                if(query.length()>1)query+=" ,";
                query+=" requesting_tm=?";
                al.add(4);
            }
            if(demandRequestEntity.getResponsibleTm()!=null){
                if(query.length()>1)query+=" ,";
                query+=" responsible_tm=?";
                al.add(5);
            }
            if(demandRequestEntity.getTargetDate()!=null){
                if(query.length()>1)query+=" ,";
                query+=" Target_date=?";
                al.add(6);
            }
            if(demandRequestEntity.getComments()!=null){
                if(query.length()>1)query+=" ,";
                query+=" comments=?";
                al.add(7);
            }
            if(demandRequestEntity.getStatus()!=null){
                if(query.length()>1)query+=" ,";
                query+=" status=?";
                if(demandRequestEntity.getStatus().equals("OFFERED")){
//                    if(demandRequestEntity.getOfferedDate()==null)throw new MandatoryDueToStatusException("If status is \"OFFERED\" then \"OfferedDate\" is mandatory field");
//                    if(demandRequestEntity.getDateOfJoiningOfferLetter()==null)throw new MandatoryDueToStatusException("If status is \"OFFERED\" then \"dojOfferLetter\" is mandatory field");
//                    if(demandRequestEntity.getRequestToOffer()==null)throw new MandatoryDueToStatusException("If status is \"OFFERED\" then \"RequestToOffer\" is mandatory field");
//                    if(demandRequestEntity.getResourceName()==null)throw new ResourceNameNotNull("If status is \"OFFERED\" then \"Resource name\" is mandatory field");
                }
                if(demandRequestEntity.getStatus().equals("RECRUITED")){
//                    if(demandRequestEntity.getActualJoiningDate()==null)throw new MandatoryDueToStatusException("If status is \"Recruited\" then \"actualDateOfJoining\"  is mandatory field");
//                    if(demandRequestEntity.getRequestTojoining()==null)throw new MandatoryDueToStatusException("If status is \"Recruited\" then \"requestToJoining\" is mandatory field");

                }
                al.add(8);
            }
            if(demandRequestEntity.getDateOfJoiningOfferLetter()!=null && demandRequestEntity.getOfferedDate()!=null){
               // if(demandRequestEntity.getDateOfJoiningOfferLetter().after(demandRequestEntity.getOfferedDate()))throw new DojGreaterThanOfferDateException("\"DOJ as per offer letter\" cannot be greater then \"Offered date\".");
            }
            if(demandRequestEntity.getRequestToOffer()!=null){
                if(query.length()>1)query+=" ,";
                query+=" request_to_offer=?";
                al.add(9);

            }if(demandRequestEntity.getOfferedDate()!=null){
                if(query.length()>1)query+=" ,";
                query+=" Offered_date=?";
                al.add(10);
            }if(demandRequestEntity.getDateOfJoiningOfferLetter()!=null){
                if(query.length()>1)query+=" ,";
                query+=" doj_offer_letter=?";
                al.add(11);
            }
            if(demandRequestEntity.getRequestTojoining()!=null){
                if(query.length()>1)query+=" ,";
                query+=" request_to_joining=?";
                al.add(12);

            }
            if(demandRequestEntity.getActualJoiningDate()!=null){
                if(query.length()>1)query+=" ,";
                query+=" actual_joining_date=?";
                al.add(13);
            }
            if(demandRequestEntity.getOfferSlaMet()!=null){
                if(query.length()>1)query+=" ,";
                query+=" offer_sla_met=?";
                al.add(14);
            }
            if(demandRequestEntity.getRemarks()!=null){
                if(query.length()>1)query+=" ,";
                query+=" remarks=?";
                al.add(15);
            }
            if(demandRequestEntity.getResourceName()!=null){
                if(query.length()>1)query+=" ,";
                query+=" resource_name=?";
                al.add(16);
            }
            query="update demand_request set  "+query+" where req_id=?";
            return query;
        }
    }

