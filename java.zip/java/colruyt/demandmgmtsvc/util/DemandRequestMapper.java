package colruyt.demandmgmtsvc.util;

import colruyt.demandmgmtsvc.model.DemandRequestEntity;

import java.sql.ResultSet;
import java.sql.SQLException;

public class DemandRequestMapper {
    public DemandRequestEntity set(ResultSet resultSet){
        DemandRequestEntity demandRequest=new DemandRequestEntity();
        try {
            demandRequest.setReqId(resultSet.getString("REQ_ID"));
            demandRequest.setRole(resultSet.getString("ROLE"));
            demandRequest.setTechnology(resultSet.getString("TECHNOLOGY"));
            demandRequest.setRequestedBy(resultSet.getString("REQUESTED_BY"));
            demandRequest.setProject(resultSet.getString("PROJECT"));
            demandRequest.setOperatingUnit(resultSet.getString("OPERATING_UNIT"));
            demandRequest.setRefCommNo(resultSet.getString("REF_COMM_NO"));
            demandRequest.setDemandLevel(resultSet.getString("DEMAND_LEVEL"));
            demandRequest.setRequestingTm(resultSet.getString("REQUESTING_TM"));
            demandRequest.setResponsibleTm(resultSet.getString("RESPONSIBLE_TM"));
            demandRequest.setRequestedDate(resultSet.getDate("REQUESTED_DATE"));
            demandRequest.setTargetDate(resultSet.getDate("TARGET_DATE"));
            demandRequest.setComments(resultSet.getString("COMMENTS"));
            demandRequest.setStatus(resultSet.getString("STATUS"));
            demandRequest.setOfferedDate(resultSet.getDate("offered_date"));
            demandRequest.setDateOfJoiningOfferLetter(resultSet.getDate("doj_offer_letter"));
            demandRequest.setOfferSlaMet(resultSet.getString("offer_sla_met"));
            demandRequest.setActualJoiningDate(resultSet.getDate("actual_joining_date"));
            demandRequest.setRequestToOffer((resultSet.getInt("request_to_offer")==0)?null:resultSet.getInt("request_to_offer"));
            demandRequest.setRequestTojoining((resultSet.getInt("request_to_joining")==0)?null:resultSet.getInt("request_to_joining"));
            demandRequest.setResourceName(resultSet.getString("resource_name"));
            demandRequest.setRemarks(resultSet.getString("remarks"));
        }
        catch (SQLException e){
            System.out.println(e.getMessage());
        }
        return demandRequest;
    }
}
