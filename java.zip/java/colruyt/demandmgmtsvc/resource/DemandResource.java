package colruyt.demandmgmtsvc.resource;

import colruyt.demandmgmtsvc.dto.DemandRequestDto;
import colruyt.demandmgmtsvc.exceptions.*;
import colruyt.demandmgmtsvc.service.DemandService;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.*;
import java.util.stream.Collectors;




@Path("/demand-request")
public class DemandResource {
    DemandService demandService = null;
    List<DemandRequestDto>demandRequests=null;
    @Path("/role")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getDemandRequestRoles() {
        Response response=null;
        List<String>roles=null;
        demandService=new DemandService();
        try{
            roles=demandService.getDemandRequestRoles();
            response=Response.status(Response.Status.OK).entity(roles).build();
        }
        catch (colruyt.demandmgmtsvc.exceptions.RolesNotFoundException e){
            response=Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
        return response;
    }

    @Path("/status")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getDemandRequestStatus(){
        Response response=null;
        List<String>status=new ArrayList<>();
        demandService=new DemandService();
        try{
            status=demandService.getDemandRequestStatus();
            response=Response.status(Response.Status.OK).entity(status).build();
        }
        catch(StatusNotFoundException e){
            response=Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
        return response;
    }
    @Path("/levels")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getDemandRequestLevels(){
        Response response=null;
        List<String>demandLevels=new ArrayList<>();
        demandService=new DemandService();
        try{
            demandLevels=demandService.getDemandRequestLevels();
            response=Response.status(Response.Status.OK).entity(demandLevels).build();
        }
        catch(LevelsNotFoundException e){
            response=Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
        return response;
    }
    @Path("/tech")
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getDemandRequestTechnologies(){
        Response response=null;
        List<String>technologies=new ArrayList<>();
        demandService=new DemandService();
        try{
            technologies=demandService.getDemandRequestTechnologies();
            response=Response.status(Response.Status.OK).entity(technologies).build();
        }
        catch (TechnologyNotFoundException e){
            response=Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
        return response;
    }

    @Path("request")
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createDemandRequest(DemandRequestDto demandRequestDto) {
        if(demandRequestDto.checkIfNullIsPresent()){
            return Response.status(Response.Status.BAD_REQUEST).entity("Null values cannot be inserted").build();
        }
        if(!demandRequestDto.getRefCommNo().startsWith("com")){
            return Response.status(Response.Status.BAD_REQUEST).entity("Reference Comm number should start with com").build();
        }
        Response response = null;
        String res = "";
        demandService = new DemandService();
        List<String> temp=new ArrayList<>();
        try {
            res=demandService.createDemandRequest(demandRequestDto);
           // res="Demand request "+res+" created";
            temp.add(res);

            response = Response.status(Response.Status.OK).entity(temp).build();
        } catch (DemandRequestNotCreatedException e) {
            response = Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
        }
        return response;
    }

        @GET
        @Path("/{reqId}")
        @Produces(MediaType.APPLICATION_JSON)
        public Response getDemandRequestById(@PathParam("reqId") String reqId){
            Response response=null;
            DemandRequestDto demandRequestDto=null;
            demandService = new DemandService();
            try{
                demandRequestDto= demandService.getDemandRequestById(reqId);
                response=Response.status(Response.Status.OK).entity(demandRequestDto).build();
            }
            catch (DemandRequestNotFoundForGivenIdException e){
                response=Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
            }
            return response;
        }

        @GET
        @Path("/getAllDemandRequest")
        @Produces(MediaType.APPLICATION_JSON)
        public Response getAllDemandRequests(){
            Response response=null;
            demandService = new DemandService();
            List<DemandRequestDto>allDemandRequests=null;
            try{
                allDemandRequests=demandService.getAllDemandRequests();
                response=Response.status(Response.Status.OK).entity(allDemandRequests).build();
            }
            catch (DemandRequestNotCreatedException e){
                response=Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
            }
            return response;
        }

        @PUT
        @Path("search")
        @Produces(MediaType.APPLICATION_JSON)
        public Response searchDemandRequests(DemandRequestDto demandRequestDto){
            Response response=null;
            demandService = new DemandService();
//            if(demandRequestDto.getReqId()!=null){
//                if(!demandRequestDto.getReqId().startsWith("D")){
//                    Response.status(Response.Status.BAD_REQUEST).entity("Request Id should start with D").build();
//                }
//        }
            if(!demandRequestDto.checkIfNotNullIsPresent()){
                return Response.status(Response.Status.BAD_REQUEST).entity("please enter one more fields").build();
            }
            try{
                demandRequests=demandService.searchDemandRequests(demandRequestDto);
                Collections.sort(demandRequests, Comparator.comparing(DemandRequestDto::getReqId));
                response=Response.status(Response.Status.OK).entity(demandRequests).build();
            }
            catch (DemandRequestNotCreatedException e){
                response=Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
            }
            catch (SearchByFieldException e){
                response=Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
            }
            catch(FutureDateException e){
                response=Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
            }
            catch (FromDateIsGreaterException e){
                response=Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
            }
            return response;
        }

        @PUT
        @Path("sortByRequestedDate")
        @Consumes(MediaType.APPLICATION_JSON)
        @Produces(MediaType.APPLICATION_JSON)
        public Response sortByRequestedDate(List<DemandRequestDto>demandRequestDtos){
            Collections.sort(demandRequestDtos,Comparator.comparing(DemandRequestDto::getRequestedDate));
            return Response.status(Response.Status.OK).entity(demandRequestDtos).build();
        }

        @PUT
        @Path("sortByTargetDate")
        @Consumes(MediaType.APPLICATION_JSON)
        @Produces(MediaType.APPLICATION_JSON)
        public Response sortByTargetDate(List<DemandRequestDto>demandRequestDtos){
            Collections.sort(demandRequestDtos,Comparator.comparing(DemandRequestDto::getTargetDate));
            return Response.status(Response.Status.OK).entity(demandRequestDtos).build();
       }

       @PUT
       @Path("/filter")
       @Consumes(MediaType.APPLICATION_JSON)
       @Produces(MediaType.APPLICATION_JSON)
       public Response filter(@QueryParam("role") String role,
                                    @QueryParam("technology") String technology,
               @QueryParam("requestedBy") String requestedBy,
               @QueryParam("project") String project,
               @QueryParam("level") String level,
               @QueryParam("status") String status, List<DemandRequestDto>demandRequestDtos){
        List<DemandRequestDto>filteredList=new ArrayList<>();
        Response response=null;
        filteredList= demandRequestDtos.stream()
                .filter(d -> ((role!=null?d.getRole().equals(role):true) &&
                        (technology!=null?d.getTechnology().equals(technology):true)&&
                        (requestedBy!=null?d.getRequestedBy().equals(requestedBy):true)&&
                        (project!=null?d.getProject().equals(project):true)&&
                        (level!=null?d.getDemandLevel().equals(level):true)&&
                        (status!=null?d.getStatus().equals(status):true)))
                 .collect(Collectors.toList());
        return Response.status(Response.Status.OK).entity(filteredList).build();
       }

       @PUT
       @Path("/{reqId}")
       @Consumes(MediaType.APPLICATION_JSON)
       @Produces(MediaType.APPLICATION_JSON)
       public Response updateDemandRequest(@PathParam("reqId") String reqId, DemandRequestDto demandRequestDto){
         //Response response=null;
         demandService=new DemandService();
           System.out.println("resource name in update"+demandRequestDto.getResourceName());
           if(demandRequestDto.getResourceName()==null){
               List<String> temp=new ArrayList<>();
               String err = "";//Resource name cannot be null
               temp.add(err);
               Response.status(Response.Status.BAD_REQUEST).entity(temp).build();
           }
           demandService.updateDemandRequest(demandRequestDto,reqId);
           List<String> temp2=new ArrayList<>();

           String res = "";//updated Succesfully
           temp2.add(res);
           return Response.status(Response.Status.OK).entity(temp2).build();
       }

       @GET
       @Path("reqBy")
       @Produces(MediaType.APPLICATION_JSON)
       public Response getRequestedBy(){
           Response response=null;
           List<String>requestedBy=new ArrayList<>();
           demandService=new DemandService();
           try{
               requestedBy=demandService.getRequestedBy();
               response=Response.status(Response.Status.OK).entity(requestedBy).build();
           }
           catch (RequestedByNotFoundException e){
               response=Response.status(Response.Status.BAD_REQUEST).entity(e.getMessage()).build();
           }
           return response;
       }
}
